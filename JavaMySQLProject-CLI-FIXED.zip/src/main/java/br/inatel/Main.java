package br.inatel;

import br.inatel.dao.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ConnectionDAO connection = new ConnectionDAO();
        if (!connection.connect()) {
            System.out.println("Falha na conexão.");
            return;
        }

        Scanner sc = new Scanner(System.in);
        int opcao = -1;

        while (opcao != 0) {
            System.out.println("\n=== SISTEMA DE GERENCIAMENTO EDUCACIONAL ===");
            System.out.println("1 - Perfil");
            System.out.println("2 - Matrícula");
            System.out.println("3 - Curso");
            System.out.println("4 - Categoria");
            System.out.println("5 - Usuário");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = sc.nextInt();
            sc.nextLine(); // limpar buffer

            switch (opcao) {
                case 1 -> menuPerfil(sc);
                case 2 -> menuMatricula(sc);
                case 3 -> menuCurso(sc);
                case 4 -> menuCategoria(sc);
                case 5 -> menuUsuario(sc);
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Opção inválida.");
            }
        }
        sc.close();
    }

    private static void menuPerfil(Scanner sc) {
        PerfilDAO dao = new PerfilDAO();
        int op;
        do {
            System.out.println("\n=== TABELA PERFIL ===");
            System.out.println("1 - Inserir novo perfil");
            System.out.println("2 - Atualizar perfil");
            System.out.println("3 - Deletar perfil");
            System.out.println("4 - Consultar dados");
            System.out.println("0 - Voltar");
            op = sc.nextInt();
            sc.nextLine();
            switch (op) {
                case 1 -> {
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Info: ");
                    String info = sc.nextLine();
                    dao.inserirPerfil(id, info);
                }
                case 2 -> {
                    System.out.print("ID do perfil a atualizar: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nova info: ");
                    String novaInfo = sc.nextLine();
                    dao.atualizarPerfil(id, novaInfo);
                }
                case 3 -> {
                    System.out.print("ID do perfil a deletar: ");
                    int id = sc.nextInt();
                    dao.deletarPerfil(id);
                }
                case 4 -> {
                    System.out.println("1 - Listar todos");
                    System.out.println("2 - Buscar por ID");
                    System.out.println("3 - Buscar com JOIN em matrícula");
                    int tipo = sc.nextInt();
                    sc.nextLine();
                    if (tipo == 1) {
                        dao.listarPerfis();
                    } else if (tipo == 2) {
                        System.out.print("ID: ");
                        int id = sc.nextInt();
                        dao.buscarPerfilPorId(id);
                    } else if (tipo == 3) {
                        dao.listarPerfisComMatricula();
                    }
                }
            }
        } while (op != 0);
    }

    private static void menuMatricula(Scanner sc) {
        MatriculaDAO dao = new MatriculaDAO();
        int op;
        do {
            System.out.println("\n=== TABELA MATRÍCULA ===");
            System.out.println("1 - Listar alunos com cursos (JOIN)");
            System.out.println("0 - Voltar");
            op = sc.nextInt();
            if (op == 1) dao.listarAlunosComCursos();
        } while (op != 0);
    }

    private static void menuCurso(Scanner sc) {
        CursoDAO dao = new CursoDAO();
        int op;
        do {
            System.out.println("\n=== TABELA CURSO ===");
            System.out.println("1 - Inserir curso");
            System.out.println("0 - Voltar");
            op = sc.nextInt();
            sc.nextLine();
            if (op == 1) {
                System.out.print("ID do curso: ");
                int id = sc.nextInt();
                System.out.print("Está disponível? (true/false): ");
                boolean disp = sc.nextBoolean();
                dao.inserirCurso(id, disp);
            }
        } while (op != 0);
    }

    private static void menuCategoria(Scanner sc) {
        CategoriaDAO dao = new CategoriaDAO();
        int op;
        do {
            System.out.println("\n=== TABELA CATEGORIA ===");
            System.out.println("1 - Listar categorias por curso");
            System.out.println("0 - Voltar");
            op = sc.nextInt();
            sc.nextLine();
            if (op == 1) {
                System.out.print("ID do curso: ");
                int idCurso = sc.nextInt();
                dao.listarCategoriasPorCurso(idCurso);
            }
        } while (op != 0);
    }

    private static void menuUsuario(Scanner sc) {
        ProcedureDAO dao = new ProcedureDAO();
        int op;
        do {
            System.out.println("\n=== TABELA USUÁRIO ===");
            System.out.println("1 - Inserir aluno via procedure");
            System.out.println("0 - Voltar");
            op = sc.nextInt();
            sc.nextLine();
            if (op == 1) {
                System.out.print("Nome do aluno: ");
                String nome = sc.nextLine();
                System.out.print("ID do perfil: ");
                int idPerfil = sc.nextInt();
                dao.inserirAlunoViaProcedure(nome, idPerfil);
            }
        } while (op != 0);
    }
}