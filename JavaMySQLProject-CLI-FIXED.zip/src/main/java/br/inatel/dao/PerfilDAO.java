package br.inatel.dao;

import java.sql.ResultSet;
import java.sql.Statement;

public class PerfilDAO extends ConnectionDAO {

    public void inserirPerfil(int idPerfil, String info) {
        try {
            Statement stmt = con.createStatement();
            String sql = "INSERT INTO perfil (ID_perfil, info) VALUES (" + idPerfil + ", '" + info + "')";
            stmt.executeUpdate(sql);
            System.out.println("Perfil inserido com sucesso.");
        } catch (Exception e) {
            System.out.println("Erro ao inserir perfil: " + e.getMessage());
        }
    }

    public void atualizarPerfil(int idPerfil, String novaInfo) {
        try {
            Statement stmt = con.createStatement();
            String sql = "UPDATE perfil SET info = '" + novaInfo + "' WHERE ID_perfil = " + idPerfil;
            stmt.executeUpdate(sql);
            System.out.println("Perfil atualizado com sucesso.");
        } catch (Exception e) {
            System.out.println("Erro ao atualizar perfil: " + e.getMessage());
        }
    }

    public void deletarPerfil(int idPerfil) {
        try {
            Statement stmt = con.createStatement();
            String sql = "DELETE FROM perfil WHERE ID_perfil = " + idPerfil;
            stmt.executeUpdate(sql);
            System.out.println("Perfil deletado com sucesso.");
        } catch (Exception e) {
            System.out.println("Erro ao deletar perfil: " + e.getMessage());
        }
    }

    public void listarPerfis() {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM perfil");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("ID_perfil") + " | Info: " + rs.getString("info"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar perfis: " + e.getMessage());
        }
    }

    public void buscarPerfilPorId(int id) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM perfil WHERE ID_perfil = " + id);
            if (rs.next()) {
                System.out.println("ID: " + rs.getInt("ID_perfil") + " | Info: " + rs.getString("info"));
            } else {
                System.out.println("Perfil não encontrado.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao buscar perfil: " + e.getMessage());
        }
    }

    public void listarPerfisComMatricula() {
        try {
            Statement stmt = con.createStatement();
            String sql = "SELECT p.ID_perfil, p.info, m.aluno FROM perfil p " +
                         "JOIN matricula m ON p.ID_perfil = m.ID_perfil";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                System.out.println("Perfil: " + rs.getInt("ID_perfil") + " | Info: " +
                                   rs.getString("info") + " | Aluno: " + rs.getString("aluno"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar com JOIN: " + e.getMessage());
        }
    }
}