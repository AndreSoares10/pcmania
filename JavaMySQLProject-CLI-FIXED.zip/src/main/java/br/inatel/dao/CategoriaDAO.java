package br.inatel.dao;

import java.sql.ResultSet;
import java.sql.Statement;

public class CategoriaDAO extends ConnectionDAO {

    public void listarCategoriasPorCurso(int idCurso) {
        try {
            Statement stmt = con.createStatement();
            String sql = "SELECT cat.tipo FROM cursos_categorias cc " +
                         "JOIN categoria cat ON cc.categoria_ID_categoria = cat.ID_categoria " +
                         "WHERE cc.curso_ID_curso = " + idCurso;
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("Categorias do curso " + idCurso + ":");
            while (rs.next()) {
                System.out.println("- " + rs.getString("tipo"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar categorias: " + e.getMessage());
        }
    }
}