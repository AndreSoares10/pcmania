package br.inatel.dao;

import java.sql.ResultSet;
import java.sql.Statement;

public class MatriculaDAO extends ConnectionDAO {

    public void listarAlunosComCursos() {
        try {
            Statement stmt = con.createStatement();
            String sql = "SELECT * FROM AlunosComCursos";
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("Alunos com cursos:");
            while (rs.next()) {
                String aluno = rs.getString("aluno");
                String perfil = rs.getString("info");
                int curso = rs.getInt("ID_curso");
                int disponivel = rs.getInt("curso_disponivel");
                System.out.println(aluno + " | " + perfil + " | Curso: " + curso + " | Disponível: " + disponivel);
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar: " + e.getMessage());
        }
    }
}