package br.inatel.dao;

import java.sql.Statement;

public class CursoDAO extends ConnectionDAO {

    public void inserirCurso(int idCurso, boolean disponivel) {
        try {
            Statement stmt = con.createStatement();
            int valorDisponivel = disponivel ? 1 : 0;
            String sql = "INSERT INTO curso (ID_curso, curso_disponivel) VALUES (" + idCurso + ", " + valorDisponivel + ")";
            stmt.executeUpdate(sql);
            System.out.println("Curso inserido com sucesso.");
        } catch (Exception e) {
            System.out.println("Erro ao inserir curso: " + e.getMessage());
        }
    }
}