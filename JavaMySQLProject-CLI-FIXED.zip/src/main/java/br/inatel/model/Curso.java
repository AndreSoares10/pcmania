package br.inatel.model;

public class Curso {
    public int idCurso;
    public boolean disponivel;

    // Getters e setters
}