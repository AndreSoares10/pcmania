package br.inatel.model;

public class Matricula {
    public int idMatricula;
    public String aluno;
    public int idPerfil;

    // Getters e setters
}