package br.inatel.model;

public class Perfil {
    public int idPerfil;
    public String info;

    // Getters e setters
}